-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Jun 2021 pada 16.42
-- Versi server: 10.4.14-MariaDB-log
-- Versi PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `siwades`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `agama`
--

CREATE TABLE `agama` (
  `id_agama` varchar(10) NOT NULL,
  `nama_agama` varchar(30) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `agama`
--

INSERT INTO `agama` (`id_agama`, `nama_agama`, `status`) VALUES
('A1', 'Islam', 1),
('A2', 'Kristen', 1),
('A3', 'Katholik', 1),
('A4', 'HIndu', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `dokumen`
--

CREATE TABLE `dokumen` (
  `id_dokumen` varchar(30) NOT NULL,
  `nama_dokumen` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `dokumen`
--

INSERT INTO `dokumen` (`id_dokumen`, `nama_dokumen`, `status`) VALUES
('D1', 'E-KTP', 1),
('D2', 'IJASAH', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `file`
--

CREATE TABLE `file` (
  `id_dokumen` varchar(30) DEFAULT NULL,
  `nik` varchar(30) DEFAULT NULL,
  `file` text DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `hak_akses`
--

CREATE TABLE `hak_akses` (
  `id_akses` varchar(10) NOT NULL,
  `nama_akses` varchar(20) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `hak_akses`
--

INSERT INTO `hak_akses` (`id_akses`, `nama_akses`, `status`) VALUES
('akses01', 'admin', 1),
('akses04', 'penduduk', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `hak_akses_user`
--

CREATE TABLE `hak_akses_user` (
  `nik` varchar(15) NOT NULL,
  `id_akses` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `hak_akses_user`
--

INSERT INTO `hak_akses_user` (`nik`, `id_akses`) VALUES
('123451', 'akses04'),
('123451', 'akses01');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kk`
--

CREATE TABLE `kk` (
  `id_kk` varchar(10) DEFAULT NULL,
  `no_kk` varchar(50) NOT NULL DEFAULT '',
  `alamat` varchar(30) DEFAULT NULL,
  `desa` varchar(30) DEFAULT NULL,
  `kecamatan` varchar(30) DEFAULT NULL,
  `kabupaten` varchar(30) DEFAULT NULL,
  `kode_pos` varchar(10) DEFAULT NULL,
  `provinsi` varchar(30) DEFAULT NULL,
  `rt` varchar(5) DEFAULT NULL,
  `rw` varchar(5) DEFAULT NULL,
  `kepala_keluarga` varchar(50) DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kk`
--

INSERT INTO `kk` (`id_kk`, `no_kk`, `alamat`, `desa`, `kecamatan`, `kabupaten`, `kode_pos`, `provinsi`, `rt`, `rw`, `kepala_keluarga`, `status`) VALUES
('1', '12341', 'Dukuh Pandean', 'TRUCUK', 'TRUCUK', 'BOJONEGORO', '62155', 'JAWA TIMUR', '07', '08', '123451', '1'),
('2', '12342', 'JL. SENGGANI', 'TRUCUK', 'TRUCUK', 'BOJONEGORO', '62155', 'JAWA TIMUR', '01', '02', '123445', '1'),
('3', '12343', 'JL. SAWAH', 'TRUCUK', 'TRUCUK', 'BOJONEGORO', '62155', 'JAWA TIMUR', '09', '09', '123453', '1'),
('4', '12344', 'JL. GERDU SUTO', 'TRUCUK', 'TRUCUK', 'BOJONEGORO', '62155', 'JAWA TIMUR', '09', '08', '123454', '1'),
('5', '12345', 'JL. HASSANUDDIN', 'TRUCUK', 'TRUCUK', 'BOJONEGORO', '62155', 'JAWA TIMUR', '08', '09', '123456', '1'),
('7', '23456', 'JL. KITA BEDA', 'TRUCUK', 'TRUCUK', 'BOJONEGORO', '62155', 'JAWA TIMUR', '14', '02', '55446576', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `klasifikasi`
--

CREATE TABLE `klasifikasi` (
  `id_klasifikasi` varchar(10) NOT NULL DEFAULT '',
  `nama_klasifikasi` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `klasifikasi`
--

INSERT INTO `klasifikasi` (`id_klasifikasi`, `nama_klasifikasi`, `status`) VALUES
('K1', 'Anak - Anak', 1),
('K2', 'Remaja', 1),
('K3', 'Dewasa', 1),
('K4', 'Lansia', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `klasifikasi_dokumen`
--

CREATE TABLE `klasifikasi_dokumen` (
  `id_klasifikasi` varchar(5) NOT NULL,
  `id_dokumen` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `klasifikasi_dokumen`
--

INSERT INTO `klasifikasi_dokumen` (`id_klasifikasi`, `id_dokumen`) VALUES
('K3', 'D1'),
('K3', 'D2'),
('K2', 'D2'),
('K4', 'D1'),
('K4', 'D2');

-- --------------------------------------------------------

--
-- Struktur dari tabel `online`
--

CREATE TABLE `online` (
  `id_online` int(11) NOT NULL,
  `nik` varchar(15) NOT NULL,
  `waktu` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `online`
--

INSERT INTO `online` (`id_online`, `nik`, `waktu`) VALUES
(7, '123451', '25-06-2021  11:10');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penduduk`
--

CREATE TABLE `penduduk` (
  `nik` varchar(100) NOT NULL,
  `nama` varchar(150) DEFAULT NULL,
  `tempat_lahir` varchar(50) DEFAULT NULL,
  `tanggal_lahir` varchar(10) DEFAULT NULL,
  `jk` enum('L','P') DEFAULT NULL,
  `golongan_darah` varchar(5) DEFAULT NULL,
  `pekerjaan` text DEFAULT NULL,
  `pendidikan` varchar(10) NOT NULL,
  `status_perkawinan` enum('KAWIN','BELUM KAWIN') NOT NULL,
  `kewarganegaraan` varchar(50) DEFAULT NULL,
  `id_agama` varchar(30) DEFAULT NULL,
  `id_klasifikasi` varchar(20) NOT NULL,
  `no_kk` varchar(50) DEFAULT NULL,
  `foto` text DEFAULT NULL,
  `about` text DEFAULT NULL,
  `username` varchar(20) NOT NULL,
  `password` text NOT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `penduduk`
--

INSERT INTO `penduduk` (`nik`, `nama`, `tempat_lahir`, `tanggal_lahir`, `jk`, `golongan_darah`, `pekerjaan`, `pendidikan`, `status_perkawinan`, `kewarganegaraan`, `id_agama`, `id_klasifikasi`, `no_kk`, `foto`, `about`, `username`, `password`, `status`) VALUES
('123445', 'AGUS SANTOSO SANTOS', 'BOJONEGORO MATOH', '14-12-2016', 'L', 'A', 'PNS', 'D2', 'BELUM KAWIN', 'WNA', 'A1', 'K1', '12342', 'foto123445.jpg', NULL, 'agus', 'YWd1c2FndXM=', 0),
('123451', 'HENDI TRI L', 'TUBAN', '21-12-1997', 'L', 'A', 'PETANI', 'SD', 'KAWIN', 'WNI', 'A1', 'K3', '12341', 'foto123451.jpg', 'maka bekali untamu dengan cukup\r\nagar dia tau arah pulang dan tak tersesat oleh riuhnya perjalanan\r\nsampai jumpa di negeri bahagia\r\n', 'admin', 'YWRtaW4=', 1),
('123452', 'MUHAMMAD ROIISUL ABIDIN', 'TUBAN', '1997-12-06', 'L', 'B', 'PNS', 'SD', 'KAWIN', 'WNA', 'A1', 'K4', '12341', 'foto123452.jpg', '', 'abidin', 'YWJpZGlu', 0),
('123453', 'COBA AJA DULU', 'TEMPAT LAHIR', '1998-12-23', 'P', 'A', 'PETANI', 'SMP', 'KAWIN', 'WNI', 'A1', 'K4', '12343', 'foto123453.jpg', '', 'coba', '1621a5dc746d5d19665ed742b2ef9736', 0),
('123454', 'FANA MAYA', 'BOJONEGORO', '1996-12-22', 'P', 'AB', 'PNS', 'S2', 'KAWIN', 'WNI', 'A1', 'K3', '12344', 'foto123454.jpg', '', 'maya', '27d3b3b3901de679a59571f85ea78c38', 0),
('123455', 'CAMELIA', 'TUBAN', '1996-12-15', 'P', 'A', 'KARYAWAN SWASTA', 'SD', 'BELUM KAWIN', 'WNI', 'A1', 'K2', '12341', 'foto123455.jpg', 'Manusia berangan lebih panjang dibandingan...\r\numur yang mampu mereka perjuangan.\r\nMendambakan banyak hal dan lupa bahwa hidupnya hanyalah bagian dari sebuah...\r\nPerjalan Pulang ~\r\n\r\n--Kashva--', 'lia', 'bc8ee6f4b9ca1e80e897ff7c68ae0b8c', 0),
('123456', 'SURYA DINATA', 'TUBAN', '1995-12-13', 'L', 'AB', 'PNS', 'SMA', 'KAWIN', 'WNA', 'A1', 'K3', '12345', 'foto123456.jpg', '\r\n', 'surya', 'aff8fbcbf1363cd7edc85a1e11391173', 0),
('123551', 'EXGE BENA VENTURA', 'BLITAR', '22-03-1996', 'L', 'B', 'PELAJAR/MAHASISWA', 'D2', 'BELUM KAWIN', 'WNI', 'A2', 'K4', '12341', 'foto123551.jpg', NULL, '', '', 0),
('55446576', 'ELFAN', 'TUBAN', '24-03-1996', 'L', 'B', 'PELAJAR/MAHASISWA', 'D2', 'BELUM KAWIN', 'WNI', 'A1', 'K2', '23456', 'foto55446576.jpg', NULL, '', '', 0),
('55667755', 'ROSYID', 'BOJONEGORO', '13-12-2016', 'L', 'AB', 'KARYAWAN SWASTA', 'D2', 'BELUM KAWIN', 'WNI', 'A1', 'K2', '23456', 'foto55667755.jpg', NULL, '', '', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesan`
--

CREATE TABLE `pesan` (
  `id_pesan` int(11) NOT NULL,
  `nik` varchar(15) NOT NULL,
  `pesan` text NOT NULL,
  `waktu` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pesan`
--

INSERT INTO `pesan` (`id_pesan`, `nik`, `pesan`, `waktu`) VALUES
(39, '123455', 'satu [kasmaran]', '10-12-2016  00:19'),
(40, '123454', 'dua  [kedip]', '10-12-2016  00:19'),
(41, '123451', 'tiga  [ketawa]', '10-12-2016  00:19'),
(42, '123451', 'tes satu dua tiga  [kasmaran] [kedip] [ketawa] [marah] [melet] [nangis] [sakit] [bye] [maki-maki] [cmarah] [cmurung] [cnangis] [csedih] [csenyum] [bonus]', '10-12-2016  00:21'),
(43, '123454', 'vhdhshdchshcbhsbhsbhbhsbdhsb', '15-12-2016  07:52'),
(44, '123454', ' [nangis] [nangis] [nangis] [nangis] [nangis] [nangis] [nangis]', '15-12-2016  07:53'),
(45, '123451', ' [cmurung] [cmurung] [cmurung] [cmurung] [bonus] [bonus] [bonus] [bonus] [bonus] [bonus]', '19-12-2016  22:00'),
(46, '123451', 'obby auliyaur rohman  [bonus] [bonus] [bonus] [bonus]', '19-12-2016  22:00'),
(47, '123451', ' [marah] [marah] [marah] [marah] [marah] [marah] [marah]', '19-12-2016  22:02'),
(48, '123445', 'iki agus', '20-12-2016  23:44'),
(49, '123445', ' [csenyum] [maki-maki] [melet] [nangis] [ketawa] [ketawa] [marah]', '20-12-2016  23:44'),
(50, '123451', ' [kasmaran] [melet] [kasmaran] [ketawa] [ketawa] [marah] [marah]', '20-12-2016  23:47'),
(51, '123454', 'malem semua [maki-maki]', '20-12-2016  23:50'),
(52, '123451', ' [bonus] [csenyum] [csedih]', '22-12-2016  01:08'),
(53, '123451', ' [cnangis] [cnangis] [cnangis]', '22-12-2016  01:18'),
(54, '123451', ' [kasmaran] [kasmaran] [kasmaran] [kasmaran] [kasmaran] [kasmaran]', '22-12-2016  01:27'),
(55, '123451', 'bjdhjhejfhekf', '22-12-2016  02:55'),
(56, '123451', ' [cmurung] [cmurung] [cmurung]', '22-12-2016  02:55'),
(57, '123451', ' [cmarah] [cmarah] [cmarah] [cmarah]', '02-01-2017  07:14'),
(58, '123451', 'aku ingin berjalan bersamamu', '05-01-2017  08:32'),
(59, '123445', 'dalam hujan dan malam gelap', '05-01-2017  08:33'),
(60, '123451', 'tapi aku tak bisa melihat matamu', '05-01-2017  09:03'),
(61, '123445', 'aku ingin berdua denganmu', '05-01-2017  09:04'),
(62, '123445', ' [bonus] [bonus] [bonus] [bonus] [bonus] [cmarah] [cmarah] [csedih] [csedih]', '05-01-2017  09:04'),
(63, '123451', ' [nangis] [nangis] [nangis] [cmarah] [cmarah] [cnangis] [cnangis] [csedih] [csedih]', '05-01-2017  09:04'),
(64, '123445', ' [bonus] [sakit] [sakit] [nangis] [nangis] [cmarah]', '05-01-2017  09:04'),
(65, '123451', ' [sakit] [sakit] [cmurung] [cmurung] [cmarah] [cmarah]', '05-01-2017  09:04'),
(66, '123451', 'p', '22-06-2021  11:43'),
(67, '123451', ' [cmarah]', '22-06-2021  11:51');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `agama`
--
ALTER TABLE `agama`
  ADD PRIMARY KEY (`id_agama`);

--
-- Indeks untuk tabel `dokumen`
--
ALTER TABLE `dokumen`
  ADD PRIMARY KEY (`id_dokumen`);

--
-- Indeks untuk tabel `hak_akses`
--
ALTER TABLE `hak_akses`
  ADD PRIMARY KEY (`id_akses`);

--
-- Indeks untuk tabel `hak_akses_user`
--
ALTER TABLE `hak_akses_user`
  ADD KEY `hak_akses_user` (`id_akses`);

--
-- Indeks untuk tabel `kk`
--
ALTER TABLE `kk`
  ADD PRIMARY KEY (`no_kk`);

--
-- Indeks untuk tabel `klasifikasi`
--
ALTER TABLE `klasifikasi`
  ADD PRIMARY KEY (`id_klasifikasi`);

--
-- Indeks untuk tabel `online`
--
ALTER TABLE `online`
  ADD PRIMARY KEY (`id_online`);

--
-- Indeks untuk tabel `penduduk`
--
ALTER TABLE `penduduk`
  ADD PRIMARY KEY (`nik`),
  ADD KEY `penduduk` (`id_agama`);

--
-- Indeks untuk tabel `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`id_pesan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `online`
--
ALTER TABLE `online`
  MODIFY `id_online` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `pesan`
--
ALTER TABLE `pesan`
  MODIFY `id_pesan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `hak_akses_user`
--
ALTER TABLE `hak_akses_user`
  ADD CONSTRAINT `hak_akses_user` FOREIGN KEY (`id_akses`) REFERENCES `hak_akses` (`id_akses`);

--
-- Ketidakleluasaan untuk tabel `penduduk`
--
ALTER TABLE `penduduk`
  ADD CONSTRAINT `penduduk` FOREIGN KEY (`id_agama`) REFERENCES `agama` (`id_agama`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

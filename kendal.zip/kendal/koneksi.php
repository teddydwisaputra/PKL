<?php 
	$_mysqli = new mysqli("localhost","root","","siwades"); 
	return $_mysqli;
 ?>